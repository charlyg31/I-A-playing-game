
import pyautogui
import cv2
import numpy as np
import pygetwindow as gw

class EPSXECapture:
    def __init__(self, window_title="ePSXe"):
        self.window_title = window_title
        self.region = self.locate_window()

    def locate_window(self):
        windows = gw.getWindowsWithTitle(self.window_title)
        if not windows:
            raise RuntimeError(f"Fenêtre '{self.window_title}' non trouvée.")
        win = windows[0]
        if not win.isActive:
            win.activate()
        bbox = (win.left, win.top, win.width, win.height)
        return bbox

    def capture(self):
        if self.region is None:
            self.region = self.locate_window()
        x, y, w, h = self.region
        image = pyautogui.screenshot(region=(x, y, w, h))
        return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)