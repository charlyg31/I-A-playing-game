
import tkinter as tk
import time
import random
from threading import Thread
import sys
import os

# Setup path for import
base = os.path.dirname(os.path.abspath(__file__))
src_root = os.path.abspath(os.path.join(base, ".."))
if src_root not in sys.path:
    sys.path.insert(0, src_root)

from controller.vjoy_controller import press_button
from core.agent.state_builder import StateBuilder
from core.audio.sound_analyzer import SoundAnalyzer
from core.memory.visual_memory import VisualMemory
from core.vision.game_analyzer import GameAnalyzer
from core.vision.visual_analyzer import VisualAnalyzer
from core.agent.human_behavior import HumanLikeBehavior
from core.agent.multimodal_agent import MultimodalAgent
from interface.dashboard import IADashboard
from interface.memory_inspector import MemoryInspector
from interface.text_memory_inspector import TextMemoryInspector
from core.agent.visual_reasoner import VisualReasoner
from core.agent.context_awareness import ContextAwareness
from core.agent.visual_cluster_memory import VisualClusterMemory
from core.agent.cluster_action_memory import ClusterActionMemory
from core.agent.cluster_text_linker import ClusterTextLinker
from interface.vision_inspector import VisionInspector
from core.vision.text_scanner import TextScanner
from core.agent.thought_generator import ThoughtGenerator
from core.agent.text_memory import TextMemory
from core.agent.memory_policy_net import MemoryPolicyNet

BUTTON_IDS = list(range(1, 15))

class PureSensorialLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("IA Dueliste - Mode Sensoriel")

        self.start_btn = tk.Button(self.root, text="Lancer l'IA", command=self.start)
        self.start_btn.pack(pady=5)

        self.pause_btn = tk.Button(self.root, text="Pause / Reprendre", command=self.toggle_pause)
        self.pause_btn.pack(pady=5)

        self.stop_btn = tk.Button(self.root, text="Arrêter", command=self.stop)
        self.stop_btn.pack(pady=5)

        self.mem_btn = tk.Button(self.root, text="Afficher/Masquer Mémoire", command=self.toggle_memory)
        self.mem_text_btn = tk.Button(self.root, text="Mémoire des pensées", command=self.toggle_text_memory)
        self.mem_text_btn.pack(pady=5)
        self.vision_btn = tk.Button(self.root, text="Vision de l'IA", command=self.toggle_vision)
        self.vision_btn.pack(pady=5)
        self.mem_btn.pack(pady=5)

        self.logbox = tk.Text(self.root, height=10, width=60)
        self.logbox.pack(pady=5)

        self.dashboard = IADashboard(self.root)
        self.memory_inspector = None
        self.memory_visible = False

        self.running = False
        self.paused = False

        self.analyzer = GameAnalyzer()
        self.visual = VisualAnalyzer()
        self.audio = SoundAnalyzer()
        self.state = StateBuilder()
        self.behavior = HumanLikeBehavior()
        self.memory = VisualMemory()
        self.text_scanner = TextScanner()
        self.thoughts = ThoughtGenerator()
        self.text_memory = TextMemory()
        self.visual_reasoner = VisualReasoner()
        self.context = ContextAwareness()
        self.cluster_memory = VisualClusterMemory(n_clusters=12)
        self.cluster_action_memory = ClusterActionMemory()
        self.cluster_text_linker = ClusterTextLinker()
        self.memory_net = MemoryPolicyNet()
        self.memory_net.train_on_memory(self.text_memory.get_all())
        self.memory_confidence = 0.6

        self.agent = MultimodalAgent(button_count=len(BUTTON_IDS))
        self.replay = []

        self.audio.start()

    def log(self, msg):
        self.logbox.insert(tk.END, msg + "\n")
        self.logbox.see(tk.END)

    def toggle_memory(self):
        if not self.memory_inspector or not self.memory_visible:
            self.memory_inspector = MemoryInspector(self.root)
            self.memory_visible = True
        else:
            self.memory_inspector.window.destroy()
            self.memory_inspector = None
            self.memory_visible = False

    def start(self):
        if not self.running:
            self.running = True
            Thread(target=self.loop, daemon=True).start()

    def toggle_pause(self):
        self.paused = not self.paused

    def stop(self):
        self.running = False
        self.audio.stop()
        self.agent.save()

    def loop(self):
        self.log("[IA] Démarrage en mode purement sensoriel...")
        while self.running:
            if self.paused:
                time.sleep(0.5)
                continue

            try:
                screen = self.analyzer.capture_screen()
                features = self.visual.process(screen)
                gray = features.get("gray")
                volume = self.audio.get_volume()

                obs = {
                    "volume": volume,
                    "last_button": 0,
                    "brightness_avg": features.get("brightness_avg", 0.0),
                    "white_zone_ratio": features.get("white_zone_ratio", 0.0)
                }

                
                
                texts_seen = self.text_scanner.extract_texts(next_screen)
                scores = self.memory_net.predict(texts_seen)
                if scores is not None:
                    best_idx = int(np.argmax(scores))
                    button_id = BUTTON_IDS[best_idx]
                    source = "mémoire_net"
                else:
                    state_vec = self.state.encode(obs)
                    idx = self.agent.act(state_vec)
                    button_id = BUTTON_IDS[idx]
                    source = "réseau" 
                best_memory = None
                for entry in reversed(self.text_memory.get_all()):
                    if any(t in entry["texts"] for t in texts_seen):
                        if entry["reward"] > 0.5:
                            best_memory = entry
                            break
                if best_memory and random.random() < self.memory_confidence:
                    button_id = best_memory["button"]
                    source = "mémoire"
                else:
                    state_vec = self.state.encode(obs)
                    idx = self.agent.act(state_vec)
                    button_id = BUTTON_IDS[idx]
                    source = "réseau"

                best_memory = None
                for entry in reversed(self.text_memory.get_all()):
                    if any(t in entry["texts"] for t in texts_seen):
                        if entry["reward"] > 0.5:
                            best_memory = entry
                            break
                if best_memory:
                    button_id = best_memory["button"]
                else:
                    state_vec = self.state.encode(obs)
                    idx = self.agent.act(state_vec)
                    button_id = BUTTON_IDS[idx]


                self.behavior.pause_for_observation()
                time.sleep(self.behavior.decision_delay())

                press_button(button_id)
                obs["last_button"] = button_id

                next_screen = self.analyzer.capture_screen()
                    if self.context.check_stuck(next_screen):
                        reward -= 0.2
                        self.log("[IA] Je suis probablement coincée ici... J'explore une sortie.")
                    if hasattr(self, 'vision_window') and self.vision_window:
                        self.vision_window.update_image(next_screen)
                after = self.visual.process(next_screen)
                delta = self.behavior.compute_visual_change(after)
                novelty = self.behavior.novelty_score(after)
                reward = self.behavior.compute_reward(delta, novelty)
                    win, lose = self.analyzer.detect_end_game_state(next_screen)
                    if win:
                        reward += 1.0
                        self.victories += 1
                    elif lose:
                        reward -= 1.0
                        self.defeats += 1
                done = False

                next_vec = self.state.encode(obs)
                self.replay.append((state_vec, idx, reward, next_vec, done))
                self.agent.replay()

                if gray is not None:
                    self.memory.record_observation(gray, button_id, reward)
                    if self.memory_inspector and self.memory_visible:
                        score_map = self.memory.button_scores[self.memory._hash_frame(gray)]
                        self.memory_inspector.update_memory(score_map)

                self.agent.remember(screen, texts_seen, volume, button_index, reward, next_screen)
                    self.dashboard.update(
                    epsilon=self.agent.epsilon,
                    reward=reward,
                    action=f"B{button_id}",
                    wins=0,
                    losses=0
                )

                
                texts_seen = self.text_scanner.extract_texts(next_screen)
                scores = self.memory_net.predict(texts_seen)
                if scores is not None:
                    best_idx = int(np.argmax(scores))
                    button_id = BUTTON_IDS[best_idx]
                    source = "mémoire_net"
                else:
                    state_vec = self.state.encode(obs)
                    idx = self.agent.act(state_vec)
                    button_id = BUTTON_IDS[idx]
                    source = "réseau" 
                best_memory = None
                for entry in reversed(self.text_memory.get_all()):
                    if any(t in entry["texts"] for t in texts_seen):
                        if entry["reward"] > 0.5:
                            best_memory = entry
                            break
                if best_memory and random.random() < self.memory_confidence:
                    button_id = best_memory["button"]
                    source = "mémoire"
                else:
                    state_vec = self.state.encode(obs)
                    idx = self.agent.act(state_vec)
                    button_id = BUTTON_IDS[idx]
                    source = "réseau"

                    thought = self.thoughts.generate(texts_seen, button_id, reward)
                    self.log(f"[IA] {thought}")
                    if hasattr(self.vision_window, 'visualizer'):
                        att_map = getattr(self.vision_window.visualizer, 'last_attention_map', None)
                        if att_map is not None:
                            reason = self.visual_reasoner.explain_attention(att_map, texts_seen)
                            self.log(f"[IA] RAISON VISUELLE : {reason}")
                        self.cluster_memory.observe(att_map)
                        cluster_id = self.cluster_memory.get_cluster_id(att_map)
                        self.log(f"[IA] CLUSTER VISUEL : {cluster_id}")
                        self.log(self.cluster_text_linker.describe(cluster_id))
                    self.log(f"[IA] Source de décision : {source.upper()}")
                    if source == 'mémoire':
                        self.memory_confidence = min(1.0, self.memory_confidence + 0.01)
                    else:
                        self.memory_confidence = max(0.2, self.memory_confidence - 0.005)
                    self.cluster_action_memory.record(cluster_id if 'cluster_id' in locals() else -1, button_id, reward)
                    self.cluster_text_linker.record(cluster_id if 'cluster_id' in locals() else -1, texts_seen)
                    self.text_memory.record(texts_seen, button_id, reward, thought, visual_reason=reason if 'reason' in locals() else None, visual_cluster_id=cluster_id if 'cluster_id' in locals() else None)
                    self.log(f"[IA] Bouton pressé : B{button_id} | Reward: {reward:.2f} | ΔImage: {delta:.2f}")

            except Exception as e:
                self.log(f"[ERREUR] {e}")
                time.sleep(1)

if __name__ == "__main__":
    PureSensorialLauncher().root.mainloop()


    def toggle_text_memory(self):
        if not hasattr(self, 'text_mem_visible') or not self.text_mem_visible:
            self.text_mem_viewer = TextMemoryInspector(self.root)
            self.text_mem_visible = True
        else:
            if self.text_mem_viewer:
                self.text_mem_viewer.window.destroy()
                self.text_mem_viewer = None
            self.text_mem_visible = False


    def toggle_vision(self):
        if not hasattr(self, 'vision_visible') or not self.vision_visible:
            self.vision_window = VisionInspector(self.root)
            self.vision_visible = True
        else:
            if self.vision_window:
                self.vision_window.window.destroy()
                self.vision_window = None
            self.vision_visible = False